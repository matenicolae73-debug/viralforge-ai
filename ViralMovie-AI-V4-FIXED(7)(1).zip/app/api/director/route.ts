import { NextResponse } from "next/server";

export async function POST(request: Request) {
  try {
    const body = await request.json().catch(() => ({}));
    const scenes = Array.isArray(body?.scenes) ? body.scenes : [];
    const genre = String(body?.genre || "Cinematic");
    const directions = scenes.map((scene:any, i:number) => {
      const text = String(scene?.prompt || "");
      const lower = text.toLowerCase();
      const close = /face|emotion|whisper|secret|fear|cry|look/.test(lower);
      const action = /run|chase|fight|drive|fall|explode|escape/.test(lower);
      const night = /night|dark|moon|rain|storm/.test(lower);
      return { id:Number(scene?.id)||i+1, shot: close?"Close-up":action?"Dynamic wide shot":"Cinematic medium shot", camera: action?"Handheld tracking / controlled push-in":close?"Slow dolly-in":"Smooth cinematic tracking", lighting: night?"Low-key atmospheric lighting":"Natural cinematic lighting", mood: night?"Tense and mysterious":action?"Energetic and urgent":"Story-driven cinematic", pacing: action?"Fast":close?"Slow and emotional":"Medium", transition: i===0?"Fade in":action?"Motion cut":"Cinematic dissolve", audio: `Original ${genre.toLowerCase()} music, ambient sound, dialogue when present and synchronized SFX`, continuity:"Keep character appearance, wardrobe, environment and screen direction consistent with previous scene." };
    });
    return NextResponse.json({ok:true,director:{genre,createdAt:new Date().toISOString(),directions}});
  } catch(e) { return NextResponse.json({ok:false,error:e instanceof Error?e.message:"Director unavailable."},{status:500}); }
}
