import { NextResponse } from "next/server";

async function redis(command: string, args: string[] = []) {
  const base = process.env.KV_REST_API_URL || process.env.UPSTASH_REDIS_REST_URL;
  const token = process.env.KV_REST_API_TOKEN || process.env.UPSTASH_REDIS_REST_TOKEN;
  if (!base || !token) return null;
  const r = await fetch(`${base}/${command}/${args.map(encodeURIComponent).join("/")}`, { headers: { Authorization: `Bearer ${token}` }, cache: "no-store" });
  if (!r.ok) throw new Error(`Storage HTTP ${r.status}`);
  return r.json();
}

export async function POST(request: Request) {
  try {
    const body = await request.json().catch(() => ({}));
    const slug = String(body?.slug || "").trim();
    const action = String(body?.action || "").trim();
    if (!slug || !["like","view"].includes(action)) return NextResponse.json({ ok:false, error:"Invalid engagement request." }, {status:400});
    const key = `vm:movie:${slug}`;
    const current = await redis("get", [key]);
    if (!current?.result) return NextResponse.json({ok:false,error:"Movie not found."},{status:404});
    const movie = typeof current.result === "string" ? JSON.parse(current.result) : current.result;
    movie.likes = Number(movie.likes || 0); movie.views = Number(movie.views || 0);
    if (action === "like") movie.likes += 1; else movie.views += 1;
    await redis("set", [key, JSON.stringify(movie)]);
    return NextResponse.json({ok:true, likes:movie.likes, views:movie.views});
  } catch (e) { return NextResponse.json({ok:false,error:e instanceof Error?e.message:"Engagement unavailable."},{status:500}); }
}
