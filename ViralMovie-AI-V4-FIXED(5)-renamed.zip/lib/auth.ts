import { SignJWT, jwtVerify } from 'jose';
import { cookies } from 'next/headers';
const secret = new TextEncoder().encode(process.env.AUTH_SECRET || 'change-me');
export async function setSession(userId:string){ const token=await new SignJWT({userId}).setProtectedHeader({alg:'HS256'}).setExpirationTime('7d').sign(secret); (await cookies()).set('vm_session',token,{httpOnly:true,sameSite:'lax',secure:process.env.NODE_ENV==='production',path:'/'}); }
export async function getSession(){ const token=(await cookies()).get('vm_session')?.value; if(!token)return null; try{return (await jwtVerify(token,secret)).payload as {userId:string}}catch{return null;} }
export async function clearSession(){(await cookies()).delete('vm_session');}
