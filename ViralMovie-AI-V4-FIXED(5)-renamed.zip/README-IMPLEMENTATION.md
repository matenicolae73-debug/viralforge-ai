# ViralMovie AI V4 implementation

Added architecture for:
- real email/password auth with secure password hashing and HTTP-only session cookie;
- PostgreSQL Prisma schema for users, projects, films, credits, transactions and payments;
- owner role locked to `OWNER_EMAIL`;
- credits balance and ledger;
- Stripe/PayPal endpoint structure and webhook endpoints;
- owner-only Movies Online publishing endpoint;
- render pipeline endpoint for concatenating scenes/audio into one MP4;
- social upload endpoint placeholders for TikTok, Instagram, Facebook and YouTube OAuth.

Before production: install dependencies, run Prisma migration, configure environment variables, implement provider SDK flows, background workers, FFmpeg rendering, audio providers and OAuth approvals.
