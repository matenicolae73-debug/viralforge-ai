import Link from 'next/link';
import DashboardPage from '../_dashboard';
export default function Page(){return <DashboardPage title='admin' subtitle='Your ViralMovie AI workspace.'><div className='empty'><h2>admin</h2><p>This area is ready for the full feature: saved projects, real accounts, credits, publishing and administration.</p><Link className='cta' href='/'>Back to studio</Link></div></DashboardPage>}
