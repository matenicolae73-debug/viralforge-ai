import {NextResponse} from 'next/server'; import {getSession} from '@/lib/auth'; import {prisma} from '@/lib/prisma';
export async function GET(){const s=await getSession();if(!s)return NextResponse.json({message:'Unauthorized'},{status:401});const u=await prisma.user.findUnique({where:{id:s.userId},select:{credits:true,transactions:true}});return NextResponse.json(u);}
