import {NextResponse} from 'next/server'; import {getSession} from '@/lib/auth';
export async function POST(){if(!(await getSession()))return NextResponse.json({message:'Unauthorized'},{status:401});return NextResponse.json({ok:false,message:'Configure STRIPE_SECRET_KEY and price mapping first.'},{status:503});}
