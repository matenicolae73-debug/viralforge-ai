# Viral Radio — Real Listener Monitoring

This package is ready for Vercel.

- `index.html` is at the project root.
- `api/listeners.js` is the Vercel serverless endpoint.
- `package.json` is included so CI/workflows can find the project.
- Listener count starts at **0**.
- No random/fake listener numbers are generated.
- A listener is counted only after the browser successfully starts the real radio player and sends heartbeats.
- The chart starts at 0 and uses only confirmed API values.
- Set `STREAM_URL` in `index.html` to your real radio stream URL.
- For production/global counts, connect Upstash/Vercel KV and set `KV_REST_API_URL` and `KV_REST_API_TOKEN`.
- Without Redis, Vercel serverless instances can have separate in-memory counters, so Redis is required for a reliable global count.

## Deploy
Import this folder/repository into Vercel. No Next.js build is required.
