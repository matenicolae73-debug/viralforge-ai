// Vercel Serverless Function — real player heartbeats only.
// A listener exists only while their browser's radio player is playing.
// Redis/Upstash is recommended in production for shared counts.

const clients = globalThis.__viralRadioClients || (globalThis.__viralRadioClients = new Map());
const PEAK_KEY = "viral-radio:peak";

async function redis(command) {
  const url = process.env.KV_REST_API_URL || process.env.UPSTASH_REDIS_REST_URL;
  const token = process.env.KV_REST_API_TOKEN || process.env.UPSTASH_REDIS_REST_TOKEN;
  if (!url || !token) return null;
  const r = await fetch(url, { method:"POST", headers:{Authorization:`Bearer ${token}`,"Content-Type":"application/json"}, body:JSON.stringify(command) });
  if (!r.ok) throw new Error("Redis request failed");
  return (await r.json()).result;
}

function clientId(req, body) {
  const id = body && body.id;
  if (id) return String(id).slice(0,160);
  const ip = String(req.headers["x-forwarded-for"] || "").split(",")[0].trim();
  const ua = String(req.headers["user-agent"] || "").slice(0,120);
  return `${ip}|${ua}`;
}

export default async function handler(req, res) {
  res.setHeader("Cache-Control","no-store,no-cache,must-revalidate");
  if (req.method !== "POST" && req.method !== "GET") return res.status(405).json({error:"Method not allowed"});
  let body={};
  if(req.method==="POST"){
    try { body=typeof req.body==="string"?JSON.parse(req.body||"{}"):(req.body||{}); } catch { body={}; }
  }
  const id=clientId(req,body);
  const active=req.method==="POST" && body.active !== false;
  const ttl=45, now=Date.now();

  try {
    const hasRedis=!!(process.env.KV_REST_API_URL || process.env.UPSTASH_REDIS_REST_URL);
    if(hasRedis){
      const key=`viral-radio:listener:${Buffer.from(id).toString("base64url").slice(0,160)}`;
      if(active) await redis(["SET",key,String(now),"EX",ttl]); else await redis(["DEL",key]);
      let cursor="0", count=0;
      do {
        const result=await redis(["SCAN",cursor,"MATCH","viral-radio:listener:*","COUNT","1000"]);
        cursor=String(result[0]); const keys=result[1]||[];
        if(keys.length){
          const values=await redis(["MGET",...keys]);
          count += values.filter(v=>v && now-Number(v)<=ttl*1000).length;
        }
      } while(cursor!=="0");
      // Persist today's maximum concurrent value when possible.
      const old=Number((await redis(["GET",PEAK_KEY]))||0);
      const peak=Math.max(old,count);
      if(peak!==old) await redis(["SET",PEAK_KEY,String(peak),"EX",86400]);
      return res.status(200).json({listeners:count,peak,countries:0,source:"player-heartbeats"});
    }
    if(active) clients.set(id,now); else clients.delete(id);
    for(const [k,t] of clients) if(now-t>ttl*1000) clients.delete(k);
    const count=clients.size;
    return res.status(200).json({listeners:count,peak:count,countries:0,source:"player-heartbeats-local"});
  } catch(e) {
    return res.status(503).json({error:"Listener store unavailable"});
  }
}
