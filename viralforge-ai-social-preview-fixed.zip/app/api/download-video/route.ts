import { NextResponse } from "next/server"

const API_BASE = "https://api.magichour.ai/v1"

export async function GET(request: Request) {
  try {
    const apiKey = process.env.MAGIC_HOUR_API_KEY
    if (!apiKey) return NextResponse.json({ error: "MAGIC_HOUR_API_KEY is not configured on the server." }, { status: 500 })
    const id = new URL(request.url).searchParams.get("id")?.trim()
    if (!id) return NextResponse.json({ error: "Missing video project id." }, { status: 400 })

    const statusResponse = await fetch(`${API_BASE}/video-projects/${encodeURIComponent(id)}`, {
      headers: { accept: "application/json", authorization: `Bearer ${apiKey}` }, cache: "no-store",
    })
    const data = await statusResponse.json()
    if (!statusResponse.ok) return NextResponse.json({ error: data?.message || data?.error?.message || "Unable to get the video download URL." }, { status: statusResponse.status })

    const videoUrl = Array.isArray(data?.downloads) ? data.downloads[0]?.url : undefined
    if (!videoUrl) return NextResponse.json({ error: "Video download is not ready yet." }, { status: 409 })

    const videoResponse = await fetch(videoUrl)
    if (!videoResponse.ok) return NextResponse.json({ error: "Unable to download the generated video." }, { status: 502 })

    return new NextResponse(videoResponse.body, {
      status: 200,
      headers: {
        "Content-Type": videoResponse.headers.get("content-type") || "video/mp4",
        "Content-Disposition": `attachment; filename="viralforge-${id}.mp4"`,
        "Cache-Control": "no-store",
      },
    })
  } catch (error) {
    console.error("download-video error", error)
    return NextResponse.json({ error: "Unable to download the video right now." }, { status: 500 })
  }
}
